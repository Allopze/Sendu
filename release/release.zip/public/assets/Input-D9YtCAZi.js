import{r as c,d as b,j as s}from"./index-B64H9wGV.js";const p=c.forwardRef(({label:i,type:r="text",placeholder:o,error:e,id:l,className:d="",...a},x)=>{const{isDark:t}=b(),u=c.useId(),n=l||u;return s.jsxs("div",{className:"flex flex-col gap-1 w-full",children:[i&&s.jsx("label",{htmlFor:n,className:`text-xs font-semibold uppercase tracking-wider ${t?"text-zinc-500":"text-zinc-400"}`,children:i}),s.jsx("input",{ref:x,id:n,type:r,placeholder:o,className:`
          w-full p-3 rounded-2xl border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500/60
          ${t?"bg-zinc-800/50 border-zinc-700 text-zinc-200 focus-visible:border-red-500 focus-visible:bg-zinc-800 placeholder:text-zinc-600":"bg-zinc-50 border-zinc-200 text-zinc-700 focus-visible:border-red-500 focus-visible:bg-white placeholder:text-zinc-400"}
          ${e?"border-red-500":""}
          ${d}
        `,"aria-invalid":!!e,...a}),e&&s.jsx("span",{className:"text-xs text-red-500 mt-1",children:e})]})});p.displayName="Input";export{p as I};
