#!/bin/bash
# Auto-generate secrets on first run if not provided
# This runs at container startup, not at build time

ENV_FILE="/app/.env"
ENV_EXAMPLE="/app/.env.example"

# If .env doesn't exist but .env.example does, copy it
if [ ! -f "$ENV_FILE" ] && [ -f "$ENV_EXAMPLE" ]; then
    cp "$ENV_EXAMPLE" "$ENV_FILE"
fi

# If SESSION_SECRET is not set or is the placeholder, generate one
if [ -z "$SESSION_SECRET" ] || [ "$SESSION_SECRET" = "your-super-secret-session-key-change-this" ]; then
    if [ -f "$ENV_FILE" ]; then
        # Generate secure secret
        NEW_SECRET=$(openssl rand -hex 64 2>/dev/null || cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 128 | head -n 1)
        
        # Update .env file
        if grep -q "^SESSION_SECRET=" "$ENV_FILE"; then
            sed -i "s/^SESSION_SECRET=.*/SESSION_SECRET=$NEW_SECRET/" "$ENV_FILE"
        else
            echo "SESSION_SECRET=$NEW_SECRET" >> "$ENV_FILE"
        fi
        
        echo "✅ Generated new SESSION_SECRET"
    fi
    export SESSION_SECRET="$NEW_SECRET"
fi

# Warn if PUBLIC_ORIGIN is not set
if [ -z "$PUBLIC_ORIGIN" ] || [ "$PUBLIC_ORIGIN" = "https://yourdomain.com" ]; then
    echo "⚠️  WARNING: PUBLIC_ORIGIN is not configured. Please set it in .env or as environment variable."
fi
