# Sendu v1.0.0

File sharing application - Production Build
Generated: 2026-03-31T22:08:00.479Z

## Quick Start with Docker (Recommended)

1. **Configure environment variables**:
   
   Copy the example and edit:
   ```bash
   cp .env.example .env
   nano .env
   ```
   Required: Set `PUBLIC_ORIGIN` to your actual domain:
   ```
   PUBLIC_ORIGIN=https://your-actual-domain.com
   ```
   NOTE: `SESSION_SECRET` is required. Generate one with:
   ```bash
   openssl rand -hex 64
   ```

2. Start the application:
   ```bash
   docker compose up -d --build
   ```

3. Access the application at your configured URL (default: `http://localhost:4000`)

## Security Notes
**Secrets are NOT included in the build artifact**:
- `SESSION_SECRET` must be set via environment variable or .env file
- `PUBLIC_ORIGIN` must be set to your domain
- Never commit .env files with real secrets to version control

## Manual Installation (Without Docker)

1. Install dependencies:
   ```bash
   npm install --production
   ```

2. Copy and configure environment:
   ```bash
   cp .env.example .env
   # Generate a session secret
   openssl rand -hex 64
   # Edit .env and add the secret
   nano .env
   ```

3. Start the server:
   ```bash
   npm start
   # Or use: ./start.sh (Linux) or start.bat (Windows)
   ```

## Data Persistence

The following directories contain persistent data:
- `data/` - SQLite database (users, files, sessions, CSRF tokens)
- `uploads/` - Uploaded files
- `backend/logs/` - Application logs
- `branding/` - Custom branding files

## Multi-Replica Support

This version supports running multiple replicas behind a load balancer:
- Sessions are stored in SQLite (shared across replicas)
- CSRF tokens are stored in SQLite
- Guest upload tracking is stored in SQLite
- Download tokens are stored in SQLite
- Background job queue is stored in SQLite (with distributed locking)

For multi-replica deployments, ensure:
1. All replicas share the same `data/` directory (via shared volume or NFS)
2. All replicas use the same `SESSION_SECRET`

## Background Job Queue

Emails and cleanup tasks run asynchronously via a persistent job queue:
- Automatic retry with exponential backoff
- Jobs survive server restarts
- Admin endpoints: `GET /api/admin/jobs/stats`, `POST /api/admin/jobs/cleanup`

## Health Check

The application exposes a health endpoint at `/api/health`

## Email Configuration (Optional)

To enable email features (password reset, notifications), edit `.env` and add:
```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=Sendu <your-email@gmail.com>
```

## Support

For issues and updates, visit the project repository.
