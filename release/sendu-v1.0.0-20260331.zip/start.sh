#!/bin/bash
echo "Starting Sendu v1.0.0..."
export NODE_ENV=production
node backend/server.js
