@echo off
echo Starting Sendu v1.0.0...
set NODE_ENV=production
node backend/server.js
